import { h } from 'preact'

import { Helmet } from 'react-helmet'

import projectStyles from '../../global-style.module.css'
import styles from './style.css'

const Home = (props) => {
  return (
    <div class={styles['container']}>
      <Helmet>
        <title>Portfolio Page</title>
        <meta property="og:title" content="Portfolio Page" />
      </Helmet>
      <div data-role="Header" class={styles['navbar-container']}>
        <div class={styles['navbar']}>
          <div class={styles['links-container']}>
            <a
              href="https://google.com"
              target="_blank"
              rel="noreferrer noopener"
              class={` ${styles['link']} ${projectStyles['navbar-link']} `}
            >
              About
            </a>
            <a
              href="https://google.com"
              target="_blank"
              rel="noreferrer noopener"
              class={` ${styles['link01']} ${projectStyles['navbar-link']} `}
            >
              Locations
            </a>
            <a
              href="https://google.com"
              target="_blank"
              rel="noreferrer noopener"
              class={` ${styles['link02']} ${projectStyles['navbar-link']} `}
            >
              Contact
            </a>
            <a
              href="https://google.com"
              target="_blank"
              rel="noreferrer noopener"
              class={styles['link03']}
            >
              Book
            </a>
          </div>
          <div data-role="BurgerMenu" class={styles['burger-menu']}>
            <svg viewBox="0 0 1024 1024" class={styles['icon']}>
              <path d="M128 256h768v86h-768v-86zM128 554v-84h768v84h-768zM128 768v-86h768v86h-768z"></path>
            </svg>
          </div>
          <div data-role="MobileMenu" class={styles['mobile-menu']}>
            <div class={styles['container01']}>
              <span
                class={` ${projectStyles['card-heading']} ${styles['heading']} `}
              >
                Logo
              </span>
              <div data-role="CloseMobileMenu" class={styles['close-menu']}>
                <svg viewBox="0 0 1024 1024" class={styles['icon2']}>
                  <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                </svg>
              </div>
            </div>
            <div class={styles['links-container1']}>
              <span
                class={` ${styles['link04']} ${projectStyles['navbar-link']} `}
              >
                About
              </span>
              <span
                class={` ${styles['link05']} ${projectStyles['navbar-link']} `}
              >
                Experience
              </span>
              <span
                class={` ${styles['link06']} ${projectStyles['navbar-link']} `}
              >
                Portofolio
              </span>
              <span class={projectStyles['navbar-link']}>Contact</span>
            </div>
          </div>
        </div>
      </div>
      <div class={styles['section-separator']}></div>
      <div class={styles['section-separator1']}></div>
      <div class={styles['container02']}>
        <div class={styles['hero']}>
          <div class={styles['hero-text-container']}>
            <h1 class={styles['heading1']}>
              The best camping experience of your life!
            </h1>
            <span class={styles['text']}>
              <span
                class={` ${projectStyles['section-text']} ${projectStyles['section-text']} `}
              >
                Book today on a platform trusted by thousands! Plan a trip to
                camp in one of these extravagant forests!
              </span>
              <br></br>
              <span class={styles['text03']}>
                Book in parties of 8 or more to save up to $100!
              </span>
              <br></br>
            </span>
            <div class={styles['cta-btn-container']}>
              <a
                href="https://google.com"
                target="_blank"
                rel="noreferrer noopener"
                class={` ${styles['cta-btn']} ${projectStyles['anchor']} ${projectStyles['button']} `}
              >
                <span class={styles['text05']}>BOOK NOW</span>
              </a>
              <a
                href="mailto:nilpatel0510@gmail.com?subject="
                class={` ${styles['cta-btn1']} ${projectStyles['button']} ${projectStyles['anchor']} `}
              >
                NEED HELP?
              </a>
            </div>
          </div>
          <a
            href="https://img.freepik.com/free-vector/template-logo-camping-vector-illustration_91861-4.jpg?size=338&amp;ext=jpg"
            class={styles['link08']}
          >
            <img
              alt="image"
              src="/assets/playground_assets/campfire-1-1500w.jpg"
              class={styles['image']}
            />
          </a>
        </div>
      </div>
      <div class={styles['features']}>
        <div class={styles['heading-container']}>
          <h2 class={styles['text06']}>Popular Locations</h2>
          <span
            class={` ${styles['text07']} ${projectStyles['section-text']} `}
          >
            From a small, inclosed camp to a large outdoor park, we have
            everything to cater your needs!
          </span>
        </div>
        <div class={styles['cards-container']}>
          <div class={styles['card']}>
            <div class={styles['icon-container']}>
              <img
                alt="image"
                src="/assets/playground_assets/scott-goodwill-y8ngwq34_ak-unsplash-200h.webp"
                class={styles['image1']}
              />
            </div>
            <div class={styles['content-container']}>
              <span class={styles['heading2']}>
                <span
                  class={` ${projectStyles['card-heading']} ${projectStyles['card-heading']} ${projectStyles['card-heading']} ${projectStyles['card-heading']} ${projectStyles['card-heading']} `}
                >
                  Yellowstone National Park
                </span>
                <br class={styles['text09']}></br>
                <br></br>
              </span>
              <span class={styles['text11']}>
                Description Camping in Yellowstone National Park is a great way
                to experience all that the park has to offer. There are a
                variety of camping options available, and you can choose from
                developed campgrounds or backcountry camping.
              </span>
            </div>
          </div>
          <div class={styles['card1']}>
            <div class={styles['icon-container1']}>
              <img
                alt="image"
                src="/assets/playground_assets/actons-campsite2-200h.jpg"
                class={styles['image2']}
              />
            </div>
            <span class={styles['heading3']}>
              Connemara National Park                                      
            </span>
            <div class={styles['content-container1']}>
              <span class={styles['text12']}>
                Connemara National Park itself encompasses part of the Twelve
                Bens mountain range, including the well-known Diamond Hill, a
                popular spot for visitors and locals alike.
              </span>
            </div>
          </div>
          <div class={styles['card2']}>
            <div class={styles['icon-container2']}>
              <img
                alt="image"
                src="/assets/playground_assets/camping-in-denali-national-park-nps-mesner-grizzly-igloo-creek-200h.jpg"
                class={styles['image3']}
              />
            </div>
            <div class={styles['content-container2']}>
              <span class={styles['heading4']}>
                <span
                  class={` ${projectStyles['card-heading']} ${projectStyles['card-heading']} ${projectStyles['card-heading']} ${projectStyles['card-heading']} ${projectStyles['card-heading']} `}
                >
                       The Denali National Park                        
                </span>
                <br></br>
              </span>
              <span class={styles['text15']}>
                In Denali, you are permitted to hike off-trail. Ride the East
                Fork Transit bus into the park and spend the day hiking through
                the wilderness. Once you are done, board another transit bus at
                the end of the day and return to the park entrance. With a
                permit, you can go backpacking in the backcountry of Denali.
              </span>
            </div>
          </div>
        </div>
      </div>
      <div class={styles['about']}>
        <div class={styles['max-content-width-container']}>
          <div class={styles['heading-container1']}>
            <h1
              class={` ${projectStyles['section-heading']} ${styles['text16']} `}
            >
              Where we are located...
            </h1>
          </div>
        </div>
        <img
          src="/assets/playground_assets/untitled-500h.jpg"
          alt="image"
          class={styles['image4']}
        />
      </div>
      <div class={styles['section-separator2']}></div>
      <div class={styles['clients']}>
        <div class={styles['heading-container2']}>
          <h1
            class={` ${styles['text17']} ${projectStyles['section-heading']} `}
          >
            Supplies we offer...
          </h1>
        </div>
        <div class={styles['logo-container']}>
          <img
            alt="image"
            src="/assets/playground_assets/41yhidqve0l._ac_sy1000_-200w.jpg"
            class={styles['logo']}
          />
          <img
            alt="image"
            src="/assets/playground_assets/04236999-200h.webp"
            class={styles['logo1']}
          />
          <img
            alt="image"
            src="/assets/playground_assets/2000035971_gsm_atf_1-1-200h.webp"
            class={styles['logo2']}
          />
          <img
            alt="image"
            src="/assets/playground_assets/61jxeqow7bl-200h.jpg"
            class={styles['logo3']}
          />
          <img
            alt="image"
            src="/assets/playground_assets/aa79578c-f104-437a-bdba-04c37a7b181b.decdefdc0bed80b0a5e8d541010ef067-200h.jpeg"
            class={styles['logo4']}
          />
        </div>
      </div>
      <div class={styles['pricing']}>
        <div class={styles['heading-container3']}>
          <h1 class={styles['text18']}>Pricing packages we offer... </h1>
        </div>
        <div class={styles['pricing-card-container']}>
          <div class={styles['card3']}>
            <div class={styles['card-heading']}>
              <span class={` ${styles['type']} ${projectStyles['anchor']} `}>
                Minimal
              </span>
              <span class={projectStyles['section-heading']}>Basic</span>
            </div>
            <div class={styles['card-content']}>
              <div class={styles['feature']}>
                <span>Gear</span>
                <span
                  class={` ${styles['limit']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <div class={styles['feature1']}>
                <span class={projectStyles['card-text']}>Food</span>
                <span
                  class={` ${styles['limit1']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <div class={styles['feature2']}>
                <span>Multiple Locations</span>
                <span
                  class={` ${styles['limit2']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <div class={styles['feature3']}>
                <span>Tour Guide</span>
                <span
                  class={` ${styles['limit3']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <a
                href="https://google.com"
                target="_blank"
                rel="noreferrer noopener"
                class={` ${styles['choose']} ${projectStyles['button']} ${projectStyles['anchor']} `}
              >
                CHOOSE
              </a>
            </div>
          </div>
          <div class={styles['card4']}>
            <div class={styles['card-heading1']}>
              <span class={` ${styles['type1']} ${projectStyles['anchor']} `}>
                medium
              </span>
              <span class={projectStyles['section-heading']}>Premium</span>
            </div>
            <div class={styles['card-content1']}>
              <div class={styles['container03']}>
                <span class={projectStyles['card-text']}>Gear</span>
                <span
                  class={` ${styles['text20']} ${projectStyles['card-text']} `}
                >
                  Yes
                </span>
              </div>
              <div class={styles['container04']}>
                <span class={projectStyles['card-text']}>Food</span>
                <span
                  class={` ${styles['text22']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <div class={styles['container05']}>
                <span class={projectStyles['card-text']}>
                  Multiple Locations
                </span>
                <span
                  class={` ${styles['text24']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <div class={styles['container06']}>
                <span>Tour Guide</span>
                <span
                  class={` ${styles['text26']} ${projectStyles['card-text']} `}
                >
                  No
                </span>
              </div>
              <a
                href="https://google.com"
                target="_blank"
                rel="noreferrer noopener"
                class={` ${styles['link09']} ${projectStyles['anchor']} ${projectStyles['button']} `}
              >
                CHOOSE
              </a>
            </div>
          </div>
          <div class={styles['card5']}>
            <div class={styles['card-heading2']}>
              <span class={` ${styles['type2']} ${projectStyles['anchor']} `}>
                Premium
              </span>
              <span class={projectStyles['section-heading']}>Deluxe</span>
            </div>
            <div class={styles['card-content2']}>
              <div class={styles['container07']}>
                <span>Gear</span>
                <span
                  class={` ${styles['text28']} ${projectStyles['card-text']} `}
                >
                  Yes
                </span>
              </div>
              <div class={styles['container08']}>
                <span class={projectStyles['card-text']}>Food</span>
                <span
                  class={` ${styles['text30']} ${projectStyles['card-text']} `}
                >
                  Yes
                </span>
              </div>
              <div class={styles['container09']}>
                <span class={projectStyles['card-text']}>
                  Multiple Locations
                </span>
                <span
                  class={` ${styles['text32']} ${projectStyles['card-text']} `}
                >
                  Yes
                </span>
              </div>
              <div class={styles['container10']}>
                <span class={projectStyles['card-text']}>Tour Guide</span>
                <span
                  class={` ${styles['text34']} ${projectStyles['card-text']} `}
                >
                  Yes
                </span>
              </div>
              <a
                href="https://google.com"
                target="_blank"
                rel="noreferrer noopener"
                class={` ${styles['link10']} ${projectStyles['anchor']} ${projectStyles['button']} `}
              >
                CHOOSE
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class={styles['section-separator3']}></div>
      <div class={styles['section-separator4']}></div>
      <div class={styles['faqs']}>
        <h2 class={styles['text35']}>Frequently Asked Questions</h2>
        <div class={styles['content-container3']}>
          <div class={styles['faq']}>
            <div class={styles['question-container']}>
              <span class={styles['question']}>Do you have refunds?</span>
            </div>
            <div class={styles['answer-container']}>
              <span
                class={` ${styles['answer']} ${projectStyles['card-text']} `}
              >
                Yes! We undertsand things happen! We offer a 24-hour full
                cancellation guarantee!
              </span>
            </div>
          </div>
          <div class={styles['faq1']}>
            <div class={styles['question-container1']}>
              <span class={styles['question1']}>Where are you located?</span>
            </div>
            <div class={styles['answer-container1']}>
              <span
                class={` ${styles['answer1']} ${projectStyles['card-text']} `}
              >
                We are located in Leadville, Colorado, United States of America
              </span>
            </div>
          </div>
          <div class={styles['faq2']}></div>
        </div>
      </div>
      <div class={styles['section-separator5']}></div>
      <div class={styles['section-separator6']}></div>
    </div>
  )
}

export default Home
